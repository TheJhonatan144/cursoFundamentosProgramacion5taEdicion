public class HolaMundo {
    public static void main(String[] args) throws Exception {
        System.out.println("Hola, Java desde VSCode");
        
    }
}
